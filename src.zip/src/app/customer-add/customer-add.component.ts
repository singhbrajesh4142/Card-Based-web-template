import { Component, OnInit } from '@angular/core';

import { Customer, User } from "../models/customer";
import { Observable } from 'rxjs';
//import { CustomerAdd } from "../customer.actions";
import { select, Store } from "@ngrx/store";
import { add, success } from "../customer.actions";

@Component({
  selector: 'app-customer-add',
  templateUrl: './customer-add.component.html',
  styleUrls: ['./customer-add.component.css']
})
export class CustomerAddComponent implements OnInit {
  customers: Observable<Customer[]>; 

  constructor(private store: Store<{ customers: Customer[] }>) { 
    this.customers = store.pipe(select('customers')); 
  } 

  AddCustomer(customerName: string) { 
    const customer = new Customer(); 
    customer.name = customerName; 
    this.store.dispatch(add(customer));

    /*
    let users:User[] = [];
    for(let i=0; i<3; i++){
      const user = new User();
      user.id = i;
      user.email = i+"@gmail.com";
      user.first_name = "Brajesh"+i;
      user.last_name = "Singh"+i;
      users.push(user);
    }
    
    this.store.dispatch(success({response:users}));*/
  } 

  ngOnInit() {
  }

}
