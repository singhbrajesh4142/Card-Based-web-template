import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HttpClientModule } from "@angular/common/http";
import { StoreModule } from "@ngrx/store";
import { CustomerEffects } from "./customer.effects";
import { reducer, success_reducer } from "./customer.reducer";
import { CustomersViewComponent } from './customers-view/customers-view.component';
import { CustomerAddComponent } from './customer-add/customer-add.component';
import { EffectsModule } from '@ngrx/effects';

@NgModule({
  declarations: [
    AppComponent,
    CustomersViewComponent,
    CustomerAddComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    StoreModule.forRoot({customers: reducer, successData: success_reducer}),
    EffectsModule.forRoot([CustomerEffects])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
