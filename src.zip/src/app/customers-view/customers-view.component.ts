import { Component, OnInit } from '@angular/core';

import { Customer, User } from "../models/customer";
import { Observable } from "rxjs";
import { select, Store } from "@ngrx/store";
//import { CustomerRemove } from "../customer.actions";
import * as CustomerActions from "../customer.actions";

@Component({
  selector: 'app-customers-view',
  templateUrl: './customers-view.component.html',
  styleUrls: ['./customers-view.component.css']
})
export class CustomersViewComponent implements OnInit {
  customers: Observable<Customer[]>;

  dataFromApi: Observable<User[]>;

  constructor(private store: Store<{ customers: Customer[] }>, 
    private newStore: Store<{ successData: User[] }>) { 
    this.customers = store.pipe(select('customers')); 
    this.dataFromApi = newStore.pipe(select('successData'));
  }

  ngOnInit() {
  }


  removeCustomer(index:number) {
    this.store.dispatch(CustomerActions.remove({customerIndex: index}));
  }

}