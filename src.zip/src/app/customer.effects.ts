import { Injectable } from "@angular/core";
import { Actions, ofType, createEffect } from "@ngrx/effects";
import * as CustomerActions from "./customer.actions";
import { Customer } from './models/customer';
import { catchError, map, exhaustMap, switchMap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';


@Injectable()
export class CustomerEffects{
    
    constructor(private action$: Actions, private http: HttpClient){}

    showCustomerData$ = createEffect(() => this.action$.pipe(
        ofType(CustomerActions.add),
        exhaustMap((customerData) => { 
            console.log('Executed from Effect ' + customerData.name ); 
            return this.http.get('https://reqres.in/api/users')
            .pipe(map(responseOfGet => (console.log(responseOfGet), CustomerActions.success({response: JSON.parse(JSON.stringify(responseOfGet))}) ) ))
        } )
    ));

}