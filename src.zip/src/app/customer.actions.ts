import { createAction, props } from "@ngrx/store";
import { Customer, User } from "./models/customer";

export const add = createAction('[Customer Component] Add', props<Customer>());
export const remove = createAction('[Customer Component] Remove', props<{ customerIndex: number}>());

export const success = createAction('[REST API] Success', props<{ response: User[]}>());
