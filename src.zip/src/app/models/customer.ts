export class Customer {
    name: String = '';
}


export class User{
    id: number = 0;
    email: String = '';
    first_name: String = '';
    last_name: String = '';
}