import * as CustomerActions from "./customer.actions";
import { createReducer, on, props, Action } from '@ngrx/store';
import { Customer, User } from './models/customer';

export interface State extends Customer{}
export const initialState:State[] = [];

const CustomerReducer = createReducer(
                          initialState,
                          on(CustomerActions.add, (state, action) => ([...state,
                                                                      {...state, name:action.name}])),
                          on(CustomerActions.remove, (state, action) => ([...state.slice(0,action.customerIndex), 
                                                                          ...state.slice(action.customerIndex+1)
                                                                        ]) )
                                      );

export function reducer(state: State[], action: Action) {
   return CustomerReducer(state, action);
}

//----------------------------------------------------------------

export const initialStateSuccess: User[] = [];

const SuccessReducer = createReducer(initialStateSuccess,
  on(CustomerActions.success, (state, action) => (console.log(action.response),[...action.response])) );

export function success_reducer(state: User[], action: Action){
  return SuccessReducer(state, action);
}

